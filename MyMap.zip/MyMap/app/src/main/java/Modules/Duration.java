package Modules;

/**
 * Created by Viraj Mohite on 31-Mar-17.
 */
public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
