package Modules;

import java.util.List;

/**
 * Created by Viraj Mohite on 31-Mar-17.
 */
public interface DirectionFinderListener {
    void onDirectionFinderStart();
    void onDirectionFinderSuccess(List<Route> route);
}
